import express from "express";
import session from "express-session";
import sqlite3 from "sqlite3";
import bcrypt from "bcrypt";
import crypto from "crypto";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { Liquid } from "liquidjs";

const __dirname = dirname(fileURLToPath(import.meta.url));
const viewsRoot = join(__dirname, "views");

const liquid = new Liquid({
    root: viewsRoot,
    extname: ".liquid",
});

const db = new sqlite3.Database("database.db");

if (!/^plfanzen\{[a-z0-9_]+\}$/.test(process.env.FLAG)) {
    throw new Error("$FLAG is not a valid flag");
}

class Flag { }
Flag.prototype.name = process.env.FLAG;

db.getAsync = function (sql, ...params) {
    return new Promise((resolve, reject) => {
        this.prepare(sql).get(...params, (err, row) => {
            if (err) reject(err);
            else resolve(row);
        });
    });
};
db.runAsync = function (sql, ...params) {
    return new Promise((resolve, reject) => {
        this.prepare(sql).run(...params, (err) => {
            if (err) reject(err);
            else resolve();
        });
    });
};

async function setup() {
    await db.runAsync("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE, username TEXT UNIQUE, password_hash TEXT, verification_code TEXT)");
    if (!await db.getAsync("SELECT * FROM users WHERE username = ?", "admin")) {
        const admin_password = crypto.randomBytes(16).toString("hex");
        console.log(`Admin password: ${admin_password}`);
        const admin_password_hash = await bcrypt.hash(admin_password, 10);
        db.run("INSERT INTO users (email, username, password_hash) VALUES (?, ?, ?)", "admin@admin.com", "admin", admin_password_hash);
    }
}

const app = express();
const port = 3000;

app.engine("liquid", liquid.express());
app.set("views", viewsRoot);
app.set("view engine", "liquid");
app.use(express.urlencoded({ extended: true }));
app.use(express.static(join(__dirname, "public")));
app.use(session({
    secret: crypto.randomBytes(32).toString("hex"),
    resave: false,
    saveUninitialized: false,
}));
app.use((req, res, next) => {
    res.locals.user = req.session.user ?? null;
    next();
});

app.get("/", (req, res) => {
    res.render("index");
});

app.get("/register", (req, res) => {
    res.render("register");
});
app.post("/register", async (req, res) => {
    const { email, username, password } = req.body;

    if (!email || !username || !password) {
        return res.status(400).send("All fields are required");
    }
    if (!/^[a-zA-Z0-9]+$/.test(username)) {
        return res.status(400).send("Username can only contain letters and numbers");
    }

    const verification_code = crypto.randomBytes(16).toString("hex");
    const password_hash = await bcrypt.hash(password, 10);
    await db.runAsync("INSERT INTO users (email, username, password_hash, verification_code) VALUES (?, ?, ?, ?)", email, username, password_hash, verification_code);
    // TODO: send email with verification_code
    res.redirect("/login");
});

app.get("/verify", (req, res) => {
    const { code } = req.query;
    if (!code) {
        return res.status(400).send("Code is required");
    }
    const user = db.prepare("SELECT * FROM users WHERE verification_code = ?").get(code);
    if (!user) {
        return res.status(400).send("Invalid code");
    }
    db.prepare("UPDATE users SET verification_code = NULL WHERE verification_code = ?").run(code);
    res.redirect("/login");
});

app.get("/logout", (req, res) => {
    req.session.destroy(() => {
        res.redirect("/");
    });
});

app.get("/login", (req, res) => {
    res.render("login");
});
app.post("/login", async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return res.status(400).send("All fields are required");
    }
    const user = await db.getAsync("SELECT * FROM users WHERE email = ?", email);
    if (!user) {
        return res.status(400).send("Account not found");
    }
    if (user.verification_code !== null) {
        return res.status(400).send("This account is not verified yet. Check your email for a verification link.");
    }

    if (await bcrypt.compare(password, user.password_hash)) {
        req.session.user = {
            id: user.id,
            email: user.email,
            username: user.username,
            is_admin: user.username === "admin",
        };
        res.redirect("/");
    } else {
        return res.status(400).send("Wrong password");
    }
});

app.post("/update-password", async (req, res) => {
    const { old_password, new_password } = req.body;
    if (!old_password || !new_password) {
        return res.status(400).send("All fields are required");
    }
    if (!req.session.user) {
        return res.status(400).send("Unauthorized");
    }
    const username = req.session.user.username;
    const user = await db.getAsync("SELECT * FROM users WHERE username LIKE ?", username);
    if (!user) {
        return res.status(400).send("Account not found");
    }
    if (bcrypt.compare(old_password, user.password_hash)) {
        const new_password_hash = await bcrypt.hash(new_password, 10);
        await db.runAsync("UPDATE users SET password_hash = ? WHERE id = ?", new_password_hash, user.id);
        res.redirect("/");
    } else {
        return res.status(400).send("Wrong old password");
    }
});

app.get("/debug-template", (req, res) => {
    if (!res.locals.user?.is_admin) {
        return res.status(403).send("You must be admin to debug templates");
    }
    res.render("debug-template");
});
app.post("/debug-template", async (req, res) => {
    if (!res.locals.user?.is_admin) {
        return res.status(400).send("You must be admin to debug templates");
    }
    const template = req.body.template;
    const flag = new Flag();
    const html = await liquid.parseAndRender(template, { flag });
    res.send(html);
});

app.listen(port, async () => {
    await setup();
    console.log(`Server is running on port ${port}`);
});
