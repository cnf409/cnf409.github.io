Source-file viewer page.
